# 【书章】

- Wang, C. (2022). The strengths, weaknesses, opportunities, and threats analysis of big data analytics in healthcare. In M. Khosrow-Pour (Ed.), *Research anthology on big data analytics, architectures, and applications* (pp. 1703-1718). Hershey, PA: IGI Global.
