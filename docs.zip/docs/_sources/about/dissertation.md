# 【Dissertation 博士论文】

- (2021) Beyond Technology: Design a Value-Driven Integrative Process Model for Data Analytics [(download)](https://github.com/wcj365/love/raw/main/src/_static/pdf/wang_dissertation.pdf)