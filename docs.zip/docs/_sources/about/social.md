# 【Social Media 社媒】 

- [LinkedIn Profile 领英](https://www.linkedin.com/in/wcj365)
- [Facebook 脸书](https://www.facebook.com/wcj365)
- [Google Scholar 谷歌学者](https://scholar.google.com/citations?user=-qZM58cAAAAJ)
- [ORCID](https://orcid.org/0000-0001-8521-9420)
- [GitHub Profile](https://github.com/wcj365)