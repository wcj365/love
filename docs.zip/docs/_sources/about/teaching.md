# 【Teachings 教程】

- [DATA 690 - Stats & Data Viz with Python](https://wcj365.github.io/python-stats-dataviz)
- [DATA 606 - Data Science Capstone](https://sites.google.com/umbc.edu/data606)
- [HCIN 541 - Healthcare Systems](https://wcj365.github.io/healthcare)