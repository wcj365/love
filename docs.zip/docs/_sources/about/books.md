# 【Books 书籍】

- [Data Visualization with Plotly Express 数据可视化电子书](https://www.plotlybook.xyz)
- [Poems & Proses 乡愁永酒诗文集](https://www.wcj365.xyz) 