# 【诗文集】

![乡](_static/images/xiang.PNG)
![愁](_static/images/chou.PNG)
![永](_static/images/yong.PNG)
![酒](_static/images/jiu.PNG)
![作者王超杰](_static/images/signature.png)

[PDF版本](https://github.com/wcj365/love/raw/main/pdf/book.pdf)