# 【诗文集】

![乡](_static/images/xiang.png)
![愁](_static/images/chou.png)
![永](_static/images/yong.png)
![酒](_static/images/jiu.png)
![作者王超杰](_static/images/signature.png)

[PDF版本](https://github.com/wcj365/love/raw/main/pdf/book.pdf)