# 【Books 书籍】

- [Data Visualization with Plotly Express 数据可视化](https://www.plotlybook.xyz)
- [Poems & Proses 乡愁永酒](https://www.wcj365.xyz) .